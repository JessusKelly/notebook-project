﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для WindowAdd.xaml
    /// </summary>
    public partial class WindowAdd : Window
    {
        //Сохранение нового дела на клавишу Enter
        public static RoutedCommand AddListToDoItem = new RoutedCommand();

        public WindowAdd()
        {
            InitializeComponent();
            titleToDo.Text = null;
            descriptionToDo.Text = "Описания нет";
            dateToDo.SelectedDate = DateTime.Now;

        }
        //Событие на нажатие кнопки
        private void Button_OnClick(object sender, RoutedEventArgs e)
        {
            AddItem();
        }
        //Добавление на Enter
        private void AddItem_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            AddItem();
        }
        //Метод добавления нового дела
        private void AddItem()
        {
            MainWindow.todoList.Add(new ToDo(titleToDo.Text, Convert.ToDateTime(dateToDo.SelectedDate), descriptionToDo.Text, false));
            (this.Owner as MainWindow).listToDo.ItemsSource = null;
            (this.Owner as MainWindow).listToDo.ItemsSource = MainWindow.todoList;
            (this.Owner as MainWindow).AllDoneJob();
            this.Close();
        }
    }
}
