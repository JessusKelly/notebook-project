﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using static System.Net.WebRequestMethods;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static List<ToDo> todoList = new List<ToDo>();
        public static int DoneJob { get; set; }
        public static int AllJob { get; set; }

        public  MainWindow()
        {
            InitializeComponent();
            UnsaveJson();
            listToDo.ItemsSource = todoList;
            AllDoneJob();
        }


        //Кнопка удаления
        private void ButtonDelete_OnClick(object sender, RoutedEventArgs e)
        {
            Delete((sender as Button).DataContext as ToDo);          
        }
        //Удаление на кнопку delete
        private void Delete_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            Delete(listToDo.SelectedItem as ToDo);
        }
        //Добавление нового окна по клику
        private void ButtonAdd_OnClick(object sender, RoutedEventArgs e)
        {
            WindowNewAdd();
            SaveJson();
        }
        //Добовление нового окна по комбинации ctrl+n
        private void CreateNewToDo_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            WindowNewAdd();
            SaveJson();
        }
        //Собтыие на поставленную галочку
        private void CheckBox_OnChecked(object sender, RoutedEventArgs e)
        {
            CheckBoxEvent(sender);
            DoneJobs();
            SaveJson();
        }
        //Событие на не потсавленную галочку
        private void CheckBox_OnUnchecked(object sender, RoutedEventArgs e)
        {
            CheckBoxEvent(sender);
            DoneJobs();
            SaveJson();
        }
        //Кнопка сохранения
        private void buttonSave_OnClick(object sender, RoutedEventArgs e)
        {
            SaveTxtFile();
            SaveJson();
        }
        //Сохранение на комбинацию Crtl+s
        private void Save_OnExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            SaveTxtFile();
            SaveJson();
        }
        //Закрытие окна
        private void Window_OnClosed(object sender, EventArgs e)
        {
            SaveJson();
        }
        //Загрузка окна
        private void Window_OnLoaded(object sender, RoutedEventArgs e)
        {
            UnsaveJson();
        }
        //Метод сохранения JSON
        public void SaveJson()
        {
            string js = JsonSerializer.Serialize(todoList);
            string OutputFileDirection = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Files", "output.json");
            System.IO.File.WriteAllText(OutputFileDirection, js);
        }
        //Метод выгрузки JSON
        public void UnsaveJson()
        {
            string OutputFileDirection = System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Files", "output.json");
            string js = System.IO.File.ReadAllText(OutputFileDirection);
            todoList = JsonSerializer.Deserialize<List<ToDo>>(js);
        }
        //Метод подсчёта работ
        public void AllDoneJob()
        {
            int AllJob = todoList.Count;
            txtTotalCount.Text = AllJob.ToString();
            int DoneJob = todoList.Count(t => t.Doing);
            txtTotalCount2.Text = DoneJob.ToString();
            ProgressBar.Maximum = AllJob;
            ProgressBar.Value = DoneJob;
        }
        //Метод подсчёта сделаных работ
        public void DoneJobs()
        {
            int DoneJob = todoList.Count(t => t.Doing);
            txtTotalCount2.Text = DoneJob.ToString();
            ProgressBar.Value = DoneJob;
        }
        //Метод удаления
        private void Delete(object metod)
        {
            var result = MessageBox.Show("ВЫ УВЕРЕНЫ ЧТО ХОТИТЕ УДАЛИТЬ ЭТО ДЕЛО?", "Удаление дела",
            MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                todoList.Remove((ToDo)metod);
                listToDo.ItemsSource = null;
                listToDo.ItemsSource = todoList;
                AllDoneJob();
            }
            else { }
        }
        //Метод создания нового окна
        private void WindowNewAdd()
        {
            WindowAdd windowAdd = new WindowAdd();
            windowAdd.Owner = this;
            windowAdd.Show();
        }
        //Метод события в checkbox
        private void CheckBoxEvent(object sender)
        {
            CheckBox checkbox = sender as CheckBox;
            ToDo todo = (ToDo)checkbox.DataContext;
            todo.Doing = (bool)checkbox.IsChecked;
        }
        //Метод сохранения файла в текст
        private void SaveTxtFile()
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Text Files (*.txt)|*.txt";
            saveFile.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            saveFile.FileName = "list_todo.txt";
            if (saveFile.ShowDialog() == true)
            {
                StringBuilder sb = new StringBuilder();
                int i = 0;
                foreach (var item in listToDo.Items)
                {
                    if (todoList[i].Doing == true)
                    {
                        sb.AppendLine("☑" + todoList[i].CaseName);
                    }
                    else
                    {
                        sb.AppendLine(" " + todoList[i].CaseName);
                    }
                    sb.AppendLine();
                    sb.AppendLine(todoList[i].CaseDescrition);
                    sb.AppendLine();
                    sb.AppendLine(todoList[i].DateOfCompletion.ToString());
                    sb.AppendLine();
                    sb.AppendLine();
                    i++;
                }
                using (StreamWriter sw = new StreamWriter(saveFile.FileName))
                {
                    sw.Write(sb);
                }
            }
        }
    }

}
