﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    //Дело
    public class ToDo
    {
        public string CaseName { get; set; }
        public DateTime DateOfCompletion {get; set;}
        public string CaseDescrition { get; set;}

        public bool Doing { get; set;}

        public ToDo(string caseName, DateTime dateOfCompletion, string caseDescrition, bool doing)
        {
            this.CaseName = caseName;   
            this.DateOfCompletion = dateOfCompletion;
            this.CaseDescrition = caseDescrition;
            this.Doing = doing;
        }
    }
}
